package com.nova.ai.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.nova.ai.ChatViewModel
import com.nova.ai.actions.ActivityLog
import com.nova.ai.actions.NovaAccessibilityService

@Composable
fun SettingsScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings
    val ctx = LocalContext.current
    val voiceErr by vm.voiceError.collectAsState()
    var log by remember { mutableStateOf(ActivityLog.read(ctx)) }
    var provider by remember { mutableStateOf(s.provider) }
    var model by remember(provider) { mutableStateOf(s.model(provider)) }
    var key by remember(provider) { mutableStateOf("") }
    var sys by remember { mutableStateOf(s.systemPrompt) }
    var note by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    val a11yOn = remember(tick) { NovaAccessibilityService.instance != null }
    val hasKey = remember(provider, tick) { s.apiKey(provider).isNotBlank() }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { vm.setAvatar(uri); note = "Character image set ho gayi." }
    }
    val fc = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        focusedBorderColor = Cyan, unfocusedBorderColor = Teal,
        focusedLabelColor = Cyan, unfocusedLabelColor = Color.Gray
    )
    Column(
        Modifier.fillMaxSize().background(Color(0xFF07131A)).systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Close", color = Cyan) }
        }
        Text("AI provider", color = Cyan)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("gemini" to "Gemini", "openai" to "OpenAI", "anthropic" to "Anthropic").forEach { (id, label) ->
                FilterChip(selected = provider == id, onClick = { provider = id }, label = { Text(label) })
            }
        }
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true, colors = fc)
        OutlinedTextField(
            key, { key = it }, Modifier.fillMaxWidth(),
            label = { Text(if (hasKey) "API key (saved ✓, naya daalo to replace hogi)" else "API key") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fc
        )
        OutlinedTextField(sys, { sys = it }, Modifier.fillMaxWidth(), label = { Text("System prompt") }, minLines = 3, colors = fc)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                s.provider = provider; s.setModel(provider, model.trim())
                if (key.isNotBlank()) s.setApiKey(provider, key.trim())
                s.systemPrompt = sys; key = ""; tick++; note = "Saved."
            }) { Text("Save") }
            if (hasKey) TextButton(onClick = { s.setApiKey(provider, ""); tick++; note = "Key delete ho gayi." }) { Text("Key delete", color = Color(0xFFFF8A80)) }
        }
        HorizontalDivider(color = Teal.copy(alpha = 0.4f))
        Text("Character", color = Cyan)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Image chuno") }
            TextButton(onClick = { vm.resetAvatar(); note = "Default character wapas." }) { Text("Reset", color = Cyan) }
        }
        HorizontalDivider(color = Teal.copy(alpha = 0.4f))
        Text("Nova ki awaaz", color = Cyan)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.testVoice(false) }) { Text("English test") }
            Button(onClick = { vm.testVoice(true) }) { Text("Hindi test") }
        }
        TextButton(onClick = { runCatching { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
            Text("Phone ki Text-to-speech settings", color = Cyan)
        }
        voiceErr?.let { Text(it, color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
        HorizontalDivider(color = Teal.copy(alpha = 0.4f))
        Text("YouTube control (Accessibility)", color = Cyan)
        Text("Ye service sirf YouTube app ki screen dekhti hai, sirf aapke command par tap/double-tap karti hai, kuch record, store ya bhejti nahi. Subscribe, like ya comment jaise kaam nahi karti.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        Text(if (a11yOn) "Status: ON ✓" else "Status: OFF", color = if (a11yOn) Cyan else Color(0xFFFF8A80))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) { Text("Accessibility kholo") }
            TextButton(onClick = { tick++ }) { Text("Refresh", color = Cyan) }
        }
        Text("Android 13+ par pehle: Phone Settings > Apps > Nova AI > ⋮ > 'Allow restricted settings', phir Accessibility mein Nova AI on karo.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        HorizontalDivider(color = Teal.copy(alpha = 0.4f))
        Text("Activity log", color = Cyan)
        Text(if (log.isEmpty()) "Abhi koi action nahi hua." else log.joinToString("\n"), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { ActivityLog.clear(ctx); log = emptyList() }) { Text("Log clear", color = Cyan) }
        if (note.isNotEmpty()) Text(note, color = Cyan)
        Text("API key sirf is phone mein encrypted store hoti hai. Chat mein kabhi apni key mat bhejo.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
    }
}
