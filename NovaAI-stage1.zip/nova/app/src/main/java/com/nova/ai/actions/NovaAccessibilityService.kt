package com.nova.ai.actions

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Limited to the YouTube app (see accessibility_service_config.xml packageNames).
 * Ignores all events; only acts when Nova explicitly calls one of the functions below after a user command.
 */
class NovaAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: NovaAccessibilityService? = null
        const val YT = "com.google.android.youtube"
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    private fun ytNodes(): List<AccessibilityNodeInfo>? {
        val root = rootInActiveWindow?.takeIf { it.packageName == YT } ?: return null
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) { out.add(n); for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) } }
        walk(root)
        return out
    }

    private fun top(n: AccessibilityNodeInfo): Int { val r = Rect(); n.getBoundsInScreen(r); return r.top }

    /** Taps the n-th video in a YouTube list (heuristic: clickable item whose description has several " - " parts). */
    fun openResult(n: Int): Boolean {
        val items = (ytNodes() ?: return false).filter {
            val d = it.contentDescription?.toString().orEmpty()
            it.isClickable && d.length > 25 && d.split(" - ").size >= 4
        }.sortedBy { top(it) }
        return items.getOrNull(n - 1)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /** Taps a bottom-bar tab such as "Shorts" or "Subscriptions". */
    fun clickLabel(label: String): Boolean {
        val hit = (ytNodes() ?: return false).filter {
            it.text?.toString().orEmpty().equals(label, true) || it.contentDescription?.toString().orEmpty().startsWith(label, true)
        }.maxByOrNull { top(it) } ?: return false
        var n: AccessibilityNodeInfo? = hit
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /** Double-tap on the right/left side of the player (YouTube's seek gesture). Result cannot be verified. */
    fun seek(forward: Boolean): Boolean {
        val dm = resources.displayMetrics
        val portrait = dm.heightPixels > dm.widthPixels
        val x = dm.widthPixels * if (forward) 0.85f else 0.15f
        val y = if (portrait) dm.widthPixels * 0.35f + 80f else dm.heightPixels * 0.5f
        fun tap(start: Long) = GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, start, 40)
        val g = GestureDescription.Builder().addStroke(tap(0)).addStroke(tap(130)).build()
        return dispatchGesture(g, null, null)
    }
}
