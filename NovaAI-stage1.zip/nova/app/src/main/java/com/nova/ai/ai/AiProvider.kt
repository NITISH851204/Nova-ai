package com.nova.ai.ai

data class ChatTurn(val role: String, val text: String)

/** Stage 2 adds OpenAI / Gemini / Anthropic adapters behind this interface. */
interface AiProvider {
    val name: String
    suspend fun reply(history: List<ChatTurn>): Result<String>
}

/** Honest stand-in: no AI is connected yet, and it says so. */
class PlaceholderProvider : AiProvider {
    override val name = "placeholder"
    override suspend fun reply(history: List<ChatTurn>): Result<String> =
        Result.success("Hi! I'm Nova. No AI provider is connected yet (coming in stage 2), so I can't answer real questions right now.")
}
