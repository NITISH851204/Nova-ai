package com.nova.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow

/** Speech-to-text via Android's SpeechRecognizer. Must be used from the main thread. */
class VoiceInput(private val ctx: Context, private val onFinal: (String) -> Unit) {
    val listening = MutableStateFlow(false)
    val partial = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    private var rec: SpeechRecognizer? = null

    fun start(lang: String = "hi-IN") {
        error.value = null
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            error.value = "Is phone par speech recognition service nahi mili. Google app install/update karo."
            return
        }
        release()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(code: Int) { error.value = message(code); release() }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                release()
                if (!t.isNullOrBlank()) onFinal(t)
            }
            override fun onPartialResults(b: Bundle?) {
                partial.value = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(i)
        listening.value = true
    }

    fun stop() = release()

    private fun release() {
        rec?.destroy(); rec = null
        listening.value = false; partial.value = ""
    }

    companion object {
        fun message(code: Int): String = when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch sunai nahi diya, phir se try karo."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission nahi hai."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network problem: speech service tak nahi pahunch paaye."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai, thodi der baad try karo."
            else -> "Voice error (code $code)."
        }
    }
}
