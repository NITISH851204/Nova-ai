package com.nova.ai.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-GCM with a non-exportable Android Keystore key. */
private object SecureStore {
    private const val ALIAS = "nova_api_keys"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return g.generateKey()
    }
    fun encrypt(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        return Base64.encodeToString(c.iv + c.doFinal(s.toByteArray()), Base64.NO_WRAP)
    }
    fun decrypt(s: String): String {
        val b = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12)) }
        return String(c.doFinal(b, 12, b.size - 12))
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)

    var provider: String
        get() = p.getString("provider", "gemini")!!
        set(v) { p.edit().putString("provider", v).apply() }

    var voiceReplies: Boolean
        get() = p.getBoolean("voice", true)
        set(v) { p.edit().putBoolean("voice", v).apply() }

    var systemPrompt: String
        get() = p.getString("sys", DEFAULT_SYSTEM)!!
        set(v) { p.edit().putString("sys", v.ifBlank { DEFAULT_SYSTEM }).apply() }

    fun model(provider: String): String {
        val saved = p.getString("model_$provider", null)
        return if (saved == null || saved in RETIRED_MODELS) DEFAULT_MODELS[provider] ?: "" else saved
    }
    fun setModel(provider: String, m: String) { p.edit().putString("model_$provider", m).apply() }

    fun apiKey(provider: String): String =
        p.getString("key_$provider", null)?.let { runCatching { SecureStore.decrypt(it) }.getOrDefault("") } ?: ""

    fun setApiKey(provider: String, k: String) {
        if (k.isBlank()) p.edit().remove("key_$provider").apply()
        else p.edit().putString("key_$provider", SecureStore.encrypt(k)).apply()
    }

    companion object {
        private val RETIRED_MODELS = setOf("gemini-2.5-flash")
        val DEFAULT_MODELS = mapOf("gemini" to "gemini-3.8-flash", "openai" to "gpt-4o-mini", "anthropic" to "claude-haiku-5-5")
        const val DEFAULT_SYSTEM = "You are Nova, a warm, friendly anime-girl AI companion and assistant. " +
            "Reply in the same language the user writes in (Hindi, Hinglish or English). Keep answers short and clear, " +
            "explain hard things simply, and be honest when you are unsure. You cannot control the phone yet, " +
            "so never claim to have performed a phone action."
    }
}
