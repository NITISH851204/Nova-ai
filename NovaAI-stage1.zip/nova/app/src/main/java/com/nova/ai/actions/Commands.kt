package com.nova.ai.actions

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.KeyEvent
import kotlinx.coroutines.delay

sealed interface Action
data class OpenApp(val label: String, val pkg: String) : Action
data object OpenYouTube : Action
data class YouTubeSearch(val query: String, val play: Int = 0) : Action
data class YouTubeOpenResult(val n: Int) : Action
data class YouTubeTab(val label: String) : Action
data class YouTubeSeek(val forward: Boolean) : Action
data class PlayStore(val query: String?) : Action
data class SettingsPage(val kind: String) : Action
data class Volume(val up: Boolean) : Action
data class Media(val kind: String) : Action

/** Rule-based command parser (Hindi / Hinglish / English) + executor using normal Android APIs only. */
object Commands {
    private const val YT = "com.google.android.youtube"
    private const val PS = "com.android.vending"

    private val map = mapOf(
        "नोवा" to "nova", "यूट्यूब" to "youtube", "yt" to "youtube", "खोलो" to "kholo", "खोलिए" to "kholo", "खोल" to "kholo",
        "सर्च" to "search", "करो" to "karo", "कर" to "kar", "ढूंढो" to "dhundo", "ढूँढो" to "dhundo", "चलाओ" to "chalao",
        "प्ले" to "play", "स्टोर" to "store", "डाउनलोड" to "download", "इंस्टॉल" to "install", "वॉल्यूम" to "volume",
        "आवाज़" to "awaaz", "आवाज" to "awaaz", "कम" to "kam", "बढ़ाओ" to "badhao", "बढ़ा" to "badhao", "पॉज़" to "pause",
        "पॉज" to "pause", "रोको" to "pause", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "वाईफाई" to "wifi",
        "ब्लूटूथ" to "bluetooth", "व्हाट्सएप" to "whatsapp", "क्रोम" to "chrome", "कैमरा" to "camera", "गैलरी" to "gallery",
        "फेसबुक" to "facebook", "पहला" to "pehla", "दूसरा" to "dusra", "तीसरा" to "teesra", "वीडियो" to "video",
        "शॉर्ट्स" to "shorts", "सब्सक्रिप्शन" to "subscriptions", "आगे" to "aage", "पीछे" to "peeche", "फॉरवर्ड" to "forward", "रिवाइंड" to "rewind", "इंस्टाग्राम" to "instagram", "ऐप" to "app", "एप" to "app", "अगला" to "next", "पिछला" to "previous"
    )
    private val fillers = setOf("nova", "hey", "please", "plz", "par", "pe", "me", "mein", "on", "in", "at", "se", "from", "the", "a", "an",
        "to", "ko", "ke", "ka", "ki", "aur", "and", "karo", "kar", "do", "dena", "de", "mujhe", "mere", "video", "videos", "for", "app",
        "apps", "ek", "zara", "jara")
    private val ordinals = mapOf("pehla" to 1, "pehli" to 1, "first" to 1, "1st" to 1, "dusra" to 2, "doosra" to 2,
        "second" to 2, "2nd" to 2, "teesra" to 3, "third" to 3, "3rd" to 3)
    private val openVerbs = setOf("kholo", "khol", "open", "launch", "chalao", "chalu", "start", "lagao")
    private val searchVerbs = setOf("search", "dhundo", "dhoondo", "khojo", "find", "play", "chalao", "lagao")

    fun parse(ctx: Context, raw: String): Action? {
        val s = raw.lowercase().replace("यू ट्यूब", "यूट्यूब").replace("प्ले स्टोर", "play store")
        val toks = s.replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ").split(Regex("\\s+"))
            .filter { it.isNotBlank() }.map { map[it] ?: it }
        val set = toks.toSet()
        val hasOpen = toks.any { it in openVerbs }
        val hasSearch = toks.any { it in searchVerbs }
        val skip = fillers + openVerbs + searchVerbs + ordinals.keys

        val ord = toks.firstNotNullOfOrNull { ordinals[it] }
        val wantsPlay = toks.any { it in setOf("play", "chalao", "lagao") }
        if ("shorts" in set && hasOpen) return YouTubeTab("Shorts")
        if (("subscriptions" in set || "subscription" in set) && hasOpen) return YouTubeTab("Subscriptions")
        if ("youtube" !in set && ord != null && "video" in set && (hasOpen || hasSearch)) return YouTubeOpenResult(ord)
        if ("youtube" in set && (hasOpen || hasSearch)) {
            val q = toks.filter { it !in skip && it != "youtube" }.joinToString(" ")
            return when {
                q.isBlank() && ord != null -> YouTubeOpenResult(ord)
                q.isBlank() -> OpenYouTube
                else -> YouTubeSearch(q, ord ?: if (wantsPlay) 1 else 0)
            }
        }
        val isStore = "store" in set
        val wantsInstall = "download" in set || "install" in set
        if (isStore || wantsInstall) {
            val q = toks.filter { it !in skip && it !in setOf("store", "play", "download", "install", "google") }.joinToString(" ")
            if (q.isNotBlank() && (wantsInstall || hasSearch) && (isStore || q.split(" ").size <= 3)) return PlayStore(q)
            if (isStore && hasOpen) return PlayStore(null)
        }
        if (("settings" in set || "setting" in set) && hasOpen) {
            return SettingsPage(when {
                "wifi" in set -> "wifi"; "bluetooth" in set -> "bluetooth"
                "sound" in set || "volume" in set -> "sound"; else -> "main"
            })
        }
        if ("volume" in set || "awaaz" in set) {
            val down = set.any { it in setOf("kam", "down", "low", "lower", "decrease", "dheere", "halka") }
            val up = set.any { it in setOf("badhao", "up", "zyada", "increase", "high", "tez", "louder", "full", "max") }
            if (down != up) return Volume(up)
        }
        val core = toks.filter { it !in fillers }
        if (core.size <= 3) {
            if (set.any { it in setOf("aage", "forward") }) return YouTubeSeek(true)
            if (set.any { it in setOf("peeche", "pichhe", "rewind", "backward") }) return YouTubeSeek(false)
        }
        if (core.size <= 2) {
            when {
                "pause" in core -> return Media("pause")
                core.any { it in setOf("resume", "continue", "play", "chalu") } -> return Media("play")
                core.any { it in setOf("next", "skip") } -> return Media("next")
                core.any { it in setOf("previous", "pichla") } -> return Media("prev")
            }
        }
        if (hasOpen) {
            val name = toks.filter { it !in fillers && it !in openVerbs }.joinToString(" ")
            if (name.isNotBlank() && name.split(" ").size <= 2) {
                val hit = findApp(ctx, name)
                return if (hit != null) OpenApp(hit.first, hit.second) else OpenApp(name, "")
            }
        }
        return null
    }

    private fun findApp(ctx: Context, name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val n = name.lowercase().replace(" ", "")
        fun norm(x: String) = x.lowercase().replace(" ", "")
        return apps.firstOrNull { norm(it.first) == n } ?: apps.firstOrNull { norm(it.first).contains(n) }
    }

    fun needsConfirm(a: Action) = a is PlayStore && a.query != null

    fun describe(a: Action): String = when (a) {
        is OpenApp -> "App kholna: ${a.label}"
        OpenYouTube -> "YouTube kholna"
        is YouTubeSearch -> "YouTube par '${a.query}' search"
        is PlayStore -> if (a.query == null) "Play Store kholna" else
            "Play Store mein '${a.query}' search kholun? Sahi (official) app aap result se chunoge aur Install Google Play mein khud dabaoge."
        is SettingsPage -> "Settings kholna (${a.kind})"
        is YouTubeOpenResult -> "YouTube mein video #${a.n} kholna"
        is YouTubeTab -> "YouTube mein ${a.label} tab kholna"
        is YouTubeSeek -> if (a.forward) "YouTube video aage karna" else "YouTube video peeche karna"
        is Volume -> if (a.up) "Volume badhana" else "Volume kam karna"
        is Media -> "Media key: ${a.kind}"
    }

    private fun launch(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun view(ctx: Context, url: String, pkg: String?): Boolean {
        val base = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (pkg != null && launch(ctx, Intent(base).setPackage(pkg))) return true
        return launch(ctx, base)
    }

    private const val A11Y_OFF = "Accessibility service on nahi hai. Settings (⚙) mein 'YouTube control' se on karo, tab main YouTube mein tap kar paungi."

    private fun bringYouTube(ctx: Context): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(YT)?.let { launch(ctx, it) } ?: false

    private suspend fun poll(times: Int, gapMs: Long = 700, block: () -> Boolean): Boolean {
        repeat(times) { if (block()) return true; delay(gapMs) }
        return false
    }

    private suspend fun playing(ctx: Context): Boolean { delay(3000); return ctx.getSystemService(AudioManager::class.java).isMusicActive }

    suspend fun execute(ctx: Context, a: Action): String = when (a) {
        is OpenApp -> if (a.pkg.isBlank()) "'${a.label}' naam ka app is phone mein nahi mila." else {
            val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg)
            if (i != null && launch(ctx, i)) "${a.label} khol rahi hoon." else "${a.label} nahi khul paya."
        }
        OpenYouTube -> if (view(ctx, "https://www.youtube.com", YT)) "YouTube khol rahi hoon." else "YouTube nahi khul paya."
        is YouTubeSearch -> {
            val opened = view(ctx, "https://www.youtube.com/results?search_query=${Uri.encode(a.query)}", YT)
            val svc = NovaAccessibilityService.instance
            if (!opened) "YouTube search nahi khul paya."
            else if (a.play == 0) "YouTube par '${a.query}' ka search khol diya. Video chuno ya bolo 'pehla video chalao'."
            else if (svc == null) "Search khol diya, par video khud chalane ke liye Accessibility on karna hoga (Settings ⚙ > YouTube control)."
            else if (!poll(12) { svc.openResult(a.play) }) "Search khula, par list mein video #${a.play} nahi mila (YouTube ka layout alag ho sakta hai)."
            else if (playing(ctx)) "'${a.query}' ka video #${a.play} chal raha hai."
            else "Video #${a.play} par tap bheja, par playback shuru hota nahi dikha."
        }
        is YouTubeOpenResult -> {
            val svc = NovaAccessibilityService.instance
            if (svc == null) A11Y_OFF
            else if (!bringYouTube(ctx)) "YouTube nahi khul paya."
            else { delay(1200)
                if (!poll(8) { svc.openResult(a.n) }) "Video #${a.n} nahi mila. Pehle YouTube par search karo."
                else if (playing(ctx)) "Video #${a.n} chal raha hai." else "Video #${a.n} par tap bheja, par playback shuru hota nahi dikha." }
        }
        is YouTubeTab -> {
            val svc = NovaAccessibilityService.instance
            if (svc == null) A11Y_OFF
            else if (!bringYouTube(ctx)) "YouTube nahi khul paya."
            else { delay(1200)
                if (poll(8) { svc.clickLabel(a.label) }) "YouTube mein ${a.label} tab par tap bheja." else "${a.label} tab nahi mila." }
        }
        is YouTubeSeek -> {
            val svc = NovaAccessibilityService.instance
            if (svc == null) A11Y_OFF
            else if (!bringYouTube(ctx)) "YouTube nahi khul paya."
            else { delay(1000)
                if (svc.seek(a.forward)) "Player mein ${if (a.forward) "aage" else "peeche"} double-tap bhej diya (result verify nahi kar sakti)." else "Gesture nahi bhej paya." }
        }
        is PlayStore -> {
            val ok = if (a.query == null) ctx.packageManager.getLaunchIntentForPackage(PS)?.let { launch(ctx, it) } ?: false
            else view(ctx, "market://search?q=${Uri.encode(a.query)}&c=apps", PS) ||
                view(ctx, "https://play.google.com/store/search?q=${Uri.encode(a.query)}&c=apps", null)
            if (!ok) "Play Store nahi khul paya."
            else if (a.query == null) "Play Store khol rahi hoon."
            else "Play Store mein '${a.query}' ka search khul gaya. Official developer check karke Install aap dabana."
        }
        is SettingsPage -> {
            val act = when (a.kind) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS; else -> Settings.ACTION_SETTINGS
            }
            if (launch(ctx, Intent(act))) "Settings khol rahi hoon." else "Settings nahi khul payi."
        }
        is Volume -> {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (a.up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "Volume ab ${am.getStreamVolume(AudioManager.STREAM_MUSIC)}/${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)} hai."
        }
        is Media -> {
            val am = ctx.getSystemService(AudioManager::class.java)
            val code = when (a.kind) {
                "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; else -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            }
            val was = am.isMusicActive
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            delay(600)
            when (a.kind) {
                "pause" -> if (!was) "Abhi koi playback chal nahi raha tha."
                    else if (!am.isMusicActive) "Pause ho gaya." else "Pause command bheji, par playback ruka nahi dikh raha. App ne shayad ignore kiya."
                "play" -> if (am.isMusicActive) "Playback chalu hai." else "Play command bheji, par koi playback chalu nahi dikha. Koi media app khula/active hona chahiye."
                else -> "Command bhej di, par result verify nahi kar sakti."
            }
        }
    }
}
