package com.nova.ai.ui

enum class AvatarState { IDLE, LISTENING, THINKING, SPEAKING, HAPPY }
