package com.nova.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

val Purple = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Blue = Color(0xFF3B82F6)
val Teal = Color(0xFF14B8A6)

/** Vector anime girl (long black hair, peach top). Expression follows [state]. */
@Composable
fun VectorAvatar(state: AvatarState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "avatar")
    val pulse by t.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(1600, easing = EaseInOut), RepeatMode.Reverse), label = "pulse")
    val blink by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "blink")
    val talk by t.animateFloat(0.2f, 1f, infiniteRepeatable(tween(220), RepeatMode.Reverse), label = "talk")
    val glow = when (state) {
        AvatarState.LISTENING -> Cyan
        AvatarState.THINKING -> Blue
        AvatarState.SPEAKING, AvatarState.HAPPY -> Purple
        AvatarState.IDLE -> Teal
    }
    Canvas(modifier.size(width = 240.dp, height = 280.dp)) {
        val w = size.width; val h = size.height; val cx = w / 2
        val skin = Color(0xFFFFE0D0); val hair = Color(0xFF15121F); val top = Color(0xFFE8947E)
        val lip = Color(0xFFC4566B)
        val rx = w * 0.2f; val ry = h * 0.165f; val fy = h * 0.37f
        // glow
        val gr = w * 0.62f * pulse
        drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.45f), Color.Transparent), Offset(cx, h * 0.45f), gr), gr, Offset(cx, h * 0.45f))
        // back hair
        drawPath(Path().apply {
            moveTo(cx - w * 0.27f, h * 0.30f)
            cubicTo(cx - w * 0.30f, h * 0.04f, cx + w * 0.30f, h * 0.04f, cx + w * 0.27f, h * 0.30f)
            lineTo(cx + w * 0.34f, h * 0.88f)
            quadraticBezierTo(cx, h * 0.95f, cx - w * 0.34f, h * 0.88f)
            close()
        }, hair)
        // neck + top
        drawRoundRect(skin, Offset(cx - w * 0.05f, h * 0.52f), Size(w * 0.1f, h * 0.15f), CornerRadius(w * 0.03f))
        drawPath(Path().apply {
            moveTo(cx - w * 0.42f, h)
            quadraticBezierTo(cx - w * 0.40f, h * 0.68f, cx - w * 0.10f, h * 0.64f)
            lineTo(cx + w * 0.10f, h * 0.64f)
            quadraticBezierTo(cx + w * 0.40f, h * 0.68f, cx + w * 0.42f, h)
            close()
        }, top)
        // face
        drawOval(skin, Offset(cx - rx, fy - ry), Size(rx * 2, ry * 2))
        // front side locks
        for (s in listOf(-1f, 1f)) drawPath(Path().apply {
            moveTo(cx + s * rx * 1.12f, h * 0.30f)
            quadraticBezierTo(cx + s * rx * 1.35f, h * 0.55f, cx + s * rx * 1.2f, h * 0.84f)
            lineTo(cx + s * rx * 0.88f, h * 0.78f)
            quadraticBezierTo(cx + s * rx * 0.98f, h * 0.52f, cx + s * rx * 0.86f, h * 0.34f)
            close()
        }, hair)
        // bangs with centre part
        drawPath(Path().apply {
            moveTo(cx - rx * 1.15f, h * 0.38f)
            cubicTo(cx - rx * 1.1f, h * 0.12f, cx + rx * 1.1f, h * 0.12f, cx + rx * 1.15f, h * 0.38f)
            lineTo(cx + rx * 0.75f, h * 0.29f)
            quadraticBezierTo(cx + rx * 0.25f, h * 0.31f, cx, h * 0.20f)
            quadraticBezierTo(cx - rx * 0.25f, h * 0.31f, cx - rx * 0.75f, h * 0.29f)
            close()
        }, hair)
        // eyes
        val ey = fy + ry * 0.12f
        val closed = blink > 0.96f || state == AvatarState.HAPPY
        val iris = if (state == AvatarState.LISTENING) Cyan else Color(0xFF5C4033)
        for (s in listOf(-1f, 1f)) {
            val ex = cx + s * rx * 0.48f; val ew = rx * 0.38f; val eh = ry * 0.38f
            if (closed) {
                drawArc(hair, 200f, 140f, false, Offset(ex - ew / 2, ey - eh * 0.2f), Size(ew, eh * 0.7f), style = Stroke(w * 0.01f))
            } else {
                drawOval(Color.White, Offset(ex - ew / 2, ey - eh / 2), Size(ew, eh))
                drawOval(iris, Offset(ex - ew * 0.32f, ey - eh * 0.5f), Size(ew * 0.64f, eh))
                drawOval(Color(0xFF1A1020), Offset(ex - ew * 0.17f, ey - eh * 0.3f), Size(ew * 0.34f, eh * 0.6f))
                drawCircle(Color.White, ew * 0.09f, Offset(ex - ew * 0.1f, ey - eh * 0.22f))
                drawArc(hair, 190f, 160f, false, Offset(ex - ew / 2, ey - eh / 2), Size(ew, eh), style = Stroke(w * 0.012f))
            }
            val lift = if (state == AvatarState.THINKING && s > 0) eh * 0.5f else 0f
            drawLine(hair, Offset(ex - ew * 0.5f, ey - eh * 0.95f), Offset(ex + ew * 0.5f, ey - eh * 1.1f - lift), w * 0.007f)
            drawCircle(Color(0x66FF7A9C), rx * 0.13f, Offset(ex + s * ew * 0.2f, ey + ry * 0.45f))
        }
        // mouth
        val my = fy + ry * 0.62f; val mw = rx * 0.25f
        when (state) {
            AvatarState.SPEAKING -> drawOval(lip, Offset(cx - mw * 0.6f, my - ry * 0.05f), Size(mw * 1.2f, ry * 0.25f * talk))
            AvatarState.HAPPY -> drawArc(lip, 0f, 180f, false, Offset(cx - mw, my - ry * 0.1f), Size(mw * 2, ry * 0.2f), style = Stroke(w * 0.009f))
            AvatarState.THINKING -> drawLine(lip, Offset(cx - mw * 0.6f, my), Offset(cx + mw * 0.6f, my), w * 0.008f)
            else -> drawArc(lip, 20f, 140f, false, Offset(cx - mw * 0.8f, my - ry * 0.09f), Size(mw * 1.6f, ry * 0.14f), style = Stroke(w * 0.008f))
        }
    }
}
