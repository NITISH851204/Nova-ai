package com.nova.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

val Purple = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Blue = Color(0xFF3B82F6)

/** Stylized vector avatar drawn on a Canvas; expression changes with [state]. */
@Composable
fun NovaAvatar(state: AvatarState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "avatar")
    val pulse by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1400, easing = EaseInOut), RepeatMode.Reverse), label = "pulse")
    val blink by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "blink")
    val talk by t.animateFloat(0.2f, 1f, infiniteRepeatable(tween(220), RepeatMode.Reverse), label = "talk")
    val glow = when (state) {
        AvatarState.LISTENING -> Cyan
        AvatarState.THINKING -> Blue
        AvatarState.SPEAKING, AvatarState.HAPPY -> Purple
        AvatarState.IDLE -> Purple.copy(alpha = 0.6f)
    }
    Canvas(modifier.size(170.dp)) {
        val c = center; val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.55f), Color.Transparent), c, r), r * pulse, c)
        // hair back
        drawCircle(Color(0xFF3B2A7A), r * 0.72f, c + Offset(0f, r * 0.02f))
        // face
        drawCircle(Color(0xFFFFE4D6), r * 0.58f, c + Offset(0f, r * 0.08f))
        // fringe
        drawArc(Color(0xFF4C35A0), 180f, 180f, true, c - Offset(r * 0.62f, r * 0.62f), Size(r * 1.24f, r * 0.95f))
        val eyeY = c.y + r * 0.08f; val dx = r * 0.24f
        val closed = blink > 0.96f
        val eyeH = if (closed || state == AvatarState.HAPPY) r * 0.04f else r * 0.2f
        listOf(-dx, dx).forEach { ox ->
            if (state == AvatarState.HAPPY) {
                drawArc(Cyan, 200f, 140f, false, Offset(c.x + ox - r * 0.1f, eyeY - r * 0.06f), Size(r * 0.2f, r * 0.2f), style = Stroke(r * 0.04f))
            } else {
                drawOval(Color(0xFF1E1B4B), Offset(c.x + ox - r * 0.08f, eyeY - eyeH / 2), Size(r * 0.16f, eyeH))
                if (!closed) drawCircle(Cyan, r * 0.035f, Offset(c.x + ox + r * 0.02f, eyeY - eyeH * 0.2f))
            }
        }
        // cheeks
        listOf(-dx * 1.35f, dx * 1.35f).forEach { drawCircle(Color(0x66FF7A9C), r * 0.07f, Offset(c.x + it, eyeY + r * 0.2f)) }
        // mouth
        val my = c.y + r * 0.36f
        when (state) {
            AvatarState.SPEAKING -> drawOval(Color(0xFFB4435E), Offset(c.x - r * 0.07f, my - r * 0.04f * talk), Size(r * 0.14f, r * 0.16f * talk))
            AvatarState.HAPPY -> drawArc(Color(0xFFB4435E), 0f, 180f, false, Offset(c.x - r * 0.1f, my - r * 0.08f), Size(r * 0.2f, r * 0.14f), style = Stroke(r * 0.03f))
            AvatarState.THINKING -> drawLine(Color(0xFFB4435E), Offset(c.x - r * 0.05f, my), Offset(c.x + r * 0.05f, my), r * 0.03f)
            else -> drawArc(Color(0xFFB4435E), 20f, 140f, false, Offset(c.x - r * 0.07f, my - r * 0.07f), Size(r * 0.14f, r * 0.1f), style = Stroke(r * 0.025f))
        }
    }
}
