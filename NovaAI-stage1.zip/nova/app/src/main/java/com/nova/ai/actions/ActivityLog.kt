package com.nova.ai.actions

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Local log of automated actions (kept on this phone only). */
object ActivityLog {
    private fun f(c: Context) = File(c.filesDir, "activity.log")
    fun add(c: Context, line: String) {
        val t = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date())
        runCatching { f(c).appendText("$t | ${line.take(200)}\n") }
    }
    fun read(c: Context): List<String> =
        f(c).takeIf { it.exists() }?.readLines()?.takeLast(30)?.reversed() ?: emptyList()
    fun clear(c: Context) { f(c).delete() }
}
