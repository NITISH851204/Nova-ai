package com.nova.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/** Text-to-speech using the phone's installed TTS engine. */
class Speaker(ctx: Context) {
    val speaking = MutableStateFlow(false)
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { speaking.value = true }
                override fun onDone(id: String?) { speaking.value = false }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { speaking.value = false }
            })
        }
    }

    fun speak(text: String) {
        val t = tts ?: return
        if (!ready) return
        val clean = text.replace(Regex("https?://\\S+"), " ").replace(Regex("[*#`_>~]"), "").trim().take(1500)
        if (clean.isBlank()) return
        val lang = if (clean.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        val r = t.setLanguage(lang)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.language = Locale.US
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova")
    }

    fun stop() { tts?.stop(); speaking.value = false }
    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
