package com.nova.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/** Text-to-speech using the phone's installed TTS engine. Problems are reported in [error], never silent. */
class Speaker(ctx: Context) {
    val speaking = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (!ready) error.value = "Text-to-speech engine start nahi hua. Phone Settings > Text-to-speech mein Google engine chuno ya install karo."
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { speaking.value = true }
                override fun onDone(id: String?) { speaking.value = false }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { speaking.value = false }
                override fun onError(id: String?, errorCode: Int) { speaking.value = false; error.value = "Voice error (code $errorCode)." }
            })
        }
    }

    fun speak(text: String) {
        error.value = null
        val t = tts
        if (t == null || !ready) { error.value = "Voice engine ready nahi hai. Phone Settings > Text-to-speech check karo."; return }
        val clean = text.replace(Regex("https?://\\S+"), " ").replace(Regex("[*#`_>~]"), "").trim().take(1500)
        if (clean.isBlank()) return
        val hasDev = clean.any { it in '\u0900'..'\u097F' }
        val r = t.setLanguage(if (hasDev) Locale("hi", "IN") else Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (hasDev) { error.value = "Hindi voice data phone mein nahi hai. Settings > Text-to-speech > Google > Install voice data mein Hindi install karo."; return }
            t.language = Locale.US
        }
        if (t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova") == TextToSpeech.ERROR) error.value = "Voice play nahi ho payi."
    }

    fun stop() { tts?.stop(); speaking.value = false }
    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
