package com.nova.ai

import android.app.Application
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.actions.*
import com.nova.ai.ai.*
import com.nova.ai.data.*
import com.nova.ai.ui.AvatarState
import com.nova.ai.voice.Speaker
import com.nova.ai.voice.VoiceInput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val settings = Settings(app)
    private val dao = NovaDatabase.get(app).dao()
    private val speaker = Speaker(app)
    private val voice = VoiceInput(app) { send(it) }

    val messages = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _avatar = MutableStateFlow(AvatarState.IDLE)
    val avatar = combine(_avatar, voice.listening, speaker.speaking) { a, l, sp ->
        when { l -> AvatarState.LISTENING; sp -> AvatarState.SPEAKING; else -> a }
    }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AvatarState.IDLE)
    val listening = voice.listening
    val partial = voice.partial
    val micError = voice.error

    private val _image = MutableStateFlow<ImageBitmap?>(AvatarStore.load(app))
    val avatarImage = _image.asStateFlow()
    fun setAvatar(uri: Uri) = viewModelScope.launch {
        _image.value = withContext(Dispatchers.IO) { AvatarStore.save(getApplication(), uri) } ?: _image.value
    }
    fun resetAvatar() { AvatarStore.clear(getApplication()); _image.value = null }

    private val _voiceReplies = MutableStateFlow(settings.voiceReplies)
    val voiceReplies = _voiceReplies.asStateFlow()
    fun toggleVoice() { val v = !_voiceReplies.value; _voiceReplies.value = v; settings.voiceReplies = v; if (!v) speaker.stop() }
    fun stopSpeaking() = speaker.stop()
    val voiceError = speaker.error
    fun testVoice(hindi: Boolean) = speaker.speak(if (hindi) "नमस्ते, मैं नोवा हूँ। क्या आप मुझे सुन पा रहे हैं?" else "Hello, I am Nova. Can you hear me?")

    private val _pending = MutableStateFlow<Action?>(null)
    val pending = _pending.asStateFlow()

    private val yes = setOf("haan", "han", "ha", "yes", "yeah", "ok", "okay", "theek hai", "kar do", "हाँ", "हां", "हा", "ठीक है")
    private val no = setOf("nahi", "nahin", "no", "cancel", "mat karo", "नहीं", "ना")

    fun confirmPending(ok: Boolean) {
        val a = _pending.value ?: return
        _pending.value = null
        viewModelScope.launch {
            if (ok) runAction(a) else {
                ActivityLog.add(getApplication(), "${Commands.describe(a)} -> user ne cancel kiya")
                say("Theek hai, cancel kar diya.")
            }
        }
    }

    private suspend fun say(text: String) {
        dao.insert(MessageEntity(role = "assistant", text = text))
        if (_voiceReplies.value && !text.startsWith("⚠️")) speaker.speak(text)
    }

    private suspend fun runAction(a: Action) {
        _avatar.value = AvatarState.THINKING
        val msg = Commands.execute(getApplication(), a)
        ActivityLog.add(getApplication(), "${Commands.describe(a)} -> $msg")
        say(msg)
        _avatar.value = AvatarState.HAPPY
        delay(1500)
        _avatar.value = AvatarState.IDLE
    }

    fun toggleMic() { if (voice.listening.value) voice.stop() else { speaker.stop(); voice.start() } }
    fun setMicError(m: String) { voice.error.value = m }

    private fun provider(): AiProvider? {
        val p = settings.provider
        val key = settings.apiKey(p)
        if (key.isBlank()) return null
        val model = settings.model(p); val sys = settings.systemPrompt
        return when (p) {
            "openai" -> OpenAiProvider(key, model, sys)
            "anthropic" -> AnthropicProvider(key, model, sys)
            else -> GeminiProvider(key, model, sys)
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _avatar.value == AvatarState.THINKING) return
        viewModelScope.launch {
            dao.insert(MessageEntity(role = "user", text = t))
            if (_pending.value != null) {
                val tl = t.lowercase().trim(' ', '.', '!')
                if (tl in yes || tl in no) { confirmPending(tl in yes); return@launch }
            }
            val act = Commands.parse(getApplication(), t)
            if (act != null) {
                if (Commands.needsConfirm(act)) { _pending.value = act; say("Confirm karo: ${Commands.describe(act)} (Haan / Nahi)") }
                else runAction(act)
                return@launch
            }
            val prov = provider()
            if (prov == null) {
                dao.insert(MessageEntity(role = "assistant", text = "⚠️ API key set nahi hai. Settings (⚙) mein provider chuno aur key daalo."))
                return@launch
            }
            _avatar.value = AvatarState.THINKING
            val history = dao.snapshot()
                .filter { !it.text.startsWith("⚠️") && !it.text.startsWith("Hi! I'm Nova. No AI") }
                .map { ChatTurn(it.role, it.text) }
            prov.reply(history)
                .onSuccess { say(it); _avatar.value = AvatarState.HAPPY }
                .onFailure { dao.insert(MessageEntity(role = "assistant", text = "⚠️ ${it.message ?: "Request fail ho gayi."}")) }
            delay(1500)
            _avatar.value = AvatarState.IDLE
        }
    }

    fun clearHistory() = viewModelScope.launch { dao.clear() }
    override fun onCleared() { voice.stop(); speaker.shutdown() }
}
