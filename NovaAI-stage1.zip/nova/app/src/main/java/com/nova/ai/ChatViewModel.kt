package com.nova.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.ai.*
import com.nova.ai.data.*
import com.nova.ai.ui.AvatarState
import com.nova.ai.voice.VoiceInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = NovaDatabase.get(app).dao()
    private val provider: AiProvider = PlaceholderProvider()
    private val voice = VoiceInput(app) { send(it) }

    val messages = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _avatar = MutableStateFlow(AvatarState.IDLE)
    val avatar = combine(_avatar, voice.listening) { a, l -> if (l) AvatarState.LISTENING else a }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AvatarState.IDLE)
    val listening = voice.listening
    val partial = voice.partial
    val micError = voice.error

    fun toggleMic() { if (voice.listening.value) voice.stop() else voice.start() }
    fun setMicError(m: String) { voice.error.value = m }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _avatar.value == AvatarState.THINKING) return
        viewModelScope.launch {
            dao.insert(MessageEntity(role = "user", text = t))
            _avatar.value = AvatarState.THINKING
            val history = messages.value.map { ChatTurn(it.role, it.text) }
            provider.reply(history)
                .onSuccess { dao.insert(MessageEntity(role = "assistant", text = it)); _avatar.value = AvatarState.HAPPY }
                .onFailure { dao.insert(MessageEntity(role = "assistant", text = "Sorry, something went wrong: ${it.message}")) }
            delay(1500)
            _avatar.value = AvatarState.IDLE
        }
    }

    fun clearHistory() = viewModelScope.launch { dao.clear() }
    override fun onCleared() { voice.stop() }
}
