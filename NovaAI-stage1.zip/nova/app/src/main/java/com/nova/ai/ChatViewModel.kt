package com.nova.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.ai.*
import com.nova.ai.data.*
import com.nova.ai.ui.AvatarState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = NovaDatabase.get(app).dao()
    private val provider: AiProvider = PlaceholderProvider()

    val messages = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _avatar = MutableStateFlow(AvatarState.IDLE)
    val avatar = _avatar.asStateFlow()

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _avatar.value == AvatarState.THINKING) return
        viewModelScope.launch {
            dao.insert(MessageEntity(role = "user", text = t))
            _avatar.value = AvatarState.THINKING
            val history = messages.value.map { ChatTurn(it.role, it.text) }
            provider.reply(history)
                .onSuccess { dao.insert(MessageEntity(role = "assistant", text = it)); _avatar.value = AvatarState.HAPPY }
                .onFailure { dao.insert(MessageEntity(role = "assistant", text = "Sorry, something went wrong: ${it.message}")) }
            delay(1500)
            _avatar.value = AvatarState.IDLE
        }
    }

    fun clearHistory() = viewModelScope.launch { dao.clear() }
}
