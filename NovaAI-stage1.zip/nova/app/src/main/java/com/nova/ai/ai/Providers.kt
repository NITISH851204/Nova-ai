package com.nova.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

internal object Http {
    private val client = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()
    private const val MAX_TRIES = 3

    /** POST JSON. Retries network errors / 429 / 5xx. Error text never includes request headers (API key). */
    suspend fun post(url: String, headers: Map<String, String>, body: JSONObject): Result<JSONObject> =
        withContext(Dispatchers.IO) {
            var last: Throwable = IOException("Unknown error")
            for (attempt in 1..MAX_TRIES) {
                try {
                    val req = Request.Builder().url(url).apply { headers.forEach { (k, v) -> addHeader(k, v) } }
                        .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                    client.newCall(req).execute().use { r ->
                        val txt = r.body?.string().orEmpty()
                        if (r.isSuccessful) return@withContext Result.success(JSONObject(txt))
                        val msg = runCatching {
                            val j = JSONObject(txt)
                            j.optJSONObject("error")?.optString("message") ?: j.optString("message")
                        }.getOrNull().orEmpty().take(200)
                        val e = IOException("HTTP ${r.code}: $msg")
                        if (r.code == 429 || r.code >= 500) last = e else return@withContext Result.failure(e)
                    }
                } catch (e: IOException) { last = e }
                if (attempt < MAX_TRIES) delay(800L * attempt)
            }
            Result.failure(last)
        }
}

private fun List<ChatTurn>.clean(): List<ChatTurn> = takeLast(20).dropWhile { it.role != "user" }

class GeminiProvider(private val key: String, private val model: String, private val system: String) : AiProvider {
    override val name = "gemini"
    override suspend fun reply(history: List<ChatTurn>): Result<String> {
        val contents = JSONArray()
        history.clean().forEach {
            contents.put(JSONObject().put("role", if (it.role == "user") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", it.text))))
        }
        val body = JSONObject().put("contents", contents)
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        return Http.post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("x-goog-api-key" to key), body)
            .mapCatching { it.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text").trim() }
    }
}

class OpenAiProvider(private val key: String, private val model: String, private val system: String) : AiProvider {
    override val name = "openai"
    override suspend fun reply(history: List<ChatTurn>): Result<String> {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.clean().forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
        return Http.post("https://api.openai.com/v1/chat/completions",
            mapOf("Authorization" to "Bearer $key"), JSONObject().put("model", model).put("messages", msgs))
            .mapCatching { it.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim() }
    }
}

class AnthropicProvider(private val key: String, private val model: String, private val system: String) : AiProvider {
    override val name = "anthropic"
    override suspend fun reply(history: List<ChatTurn>): Result<String> {
        val msgs = JSONArray()
        history.clean().forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model).put("max_tokens", 1024).put("system", system).put("messages", msgs)
        return Http.post("https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
            .mapCatching { r ->
                val c = r.getJSONArray("content")
                (0 until c.length()).map { c.getJSONObject(it) }.filter { it.optString("type") == "text" }
                    .joinToString("") { it.getString("text") }.trim()
            }
    }
}
