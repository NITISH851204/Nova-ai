package com.nova.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

/** Shows the user's character image (with a state-coloured glow), or the built-in vector girl if none is set. */
@Composable
fun NovaAvatar(state: AvatarState, image: ImageBitmap?, modifier: Modifier = Modifier) {
    if (image == null) { VectorAvatar(state, modifier); return }
    val t = rememberInfiniteTransition(label = "img")
    val pulse by t.animateFloat(1f, 1.03f, infiniteRepeatable(tween(1500, easing = EaseInOut), RepeatMode.Reverse), label = "p")
    val glow = when (state) {
        AvatarState.LISTENING -> Cyan
        AvatarState.THINKING -> Blue
        AvatarState.SPEAKING, AvatarState.HAPPY -> Purple
        AvatarState.IDLE -> Teal
    }
    val shape = RoundedCornerShape(28.dp)
    Box(modifier.size(width = 250.dp, height = 300.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val r = size.width * 0.7f
            drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.5f), Color.Transparent), center, r), r, center)
        }
        Image(
            image, "Nova",
            Modifier.size(width = 200.dp, height = 250.dp)
                .scale(if (state == AvatarState.LISTENING || state == AvatarState.SPEAKING) pulse else 1f)
                .clip(shape).border(2.dp, glow, shape),
            contentScale = ContentScale.Crop
        )
    }
}
