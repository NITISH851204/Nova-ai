package com.nova.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.nova.ai.ChatViewModel
import com.nova.ai.actions.Commands
import java.util.Calendar

@Composable
private fun MicIcon(stop: Boolean) {
    Canvas(Modifier.size(26.dp)) {
        val w = size.width; val c = Color.White; val sw = w * 0.08f
        if (stop) {
            drawRoundRect(c, Offset(w * 0.28f, w * 0.28f), Size(w * 0.44f, w * 0.44f), androidx.compose.ui.geometry.CornerRadius(w * 0.06f))
        } else {
            drawRoundRect(c, Offset(w * 0.36f, w * 0.08f), Size(w * 0.28f, w * 0.5f), androidx.compose.ui.geometry.CornerRadius(w * 0.14f))
            drawArc(c, 0f, 180f, false, Offset(w * 0.24f, w * 0.3f), Size(w * 0.52f, w * 0.4f), style = Stroke(sw, cap = StrokeCap.Round))
            drawLine(c, Offset(w * 0.5f, w * 0.7f), Offset(w * 0.5f, w * 0.88f), sw, StrokeCap.Round)
            drawLine(c, Offset(w * 0.36f, w * 0.88f), Offset(w * 0.64f, w * 0.88f), sw, StrokeCap.Round)
        }
    }
}

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "mic")
    val ring by t.animateFloat(1f, 1.35f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "ring")
    Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
        if (listening) Box(Modifier.size(52.dp).scale(ring).background(Color(0x55FF4D4D), CircleShape))
        Box(
            Modifier.size(52.dp).clip(CircleShape)
                .background(if (listening) Color(0xFFE53935) else Purple)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { MicIcon(listening) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val msgs by vm.messages.collectAsState()
    val avatar by vm.avatar.collectAsState()
    val image by vm.avatarImage.collectAsState()
    val pending by vm.pending.collectAsState()
    val voiceOn by vm.voiceReplies.collectAsState()
    var showSettings by remember { mutableStateOf(false) }
    val listening by vm.listening.collectAsState()
    val partial by vm.partial.collectAsState()
    val micError by vm.micError.collectAsState()
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    val imeOpen = WindowInsets.isImeVisible
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.lastIndex) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleMic() else vm.setMicError("Mic permission nahi mili. Phone Settings > Apps > Nova AI > Permissions mein allow karo.")
    }
    val onMic = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleMic()
        else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when { hour < 12 -> "Good morning"; hour < 17 -> "Good afternoon"; else -> "Good evening" }
    val status = when (avatar) {
        AvatarState.LISTENING -> "Nova sun rahi hai…"
        AvatarState.THINKING -> "Soch rahi hai…"
        AvatarState.SPEAKING -> "Bol rahi hai…"
        else -> "Ready"
    }

    BackHandler(enabled = showSettings) { showSettings = false }
    if (showSettings) { SettingsScreen(vm) { showSettings = false }; return }

    Column(Modifier.fillMaxSize().background(Color(0xFF07131A)).systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(greeting, color = Color.White, style = MaterialTheme.typography.titleLarge)
                Text(status, color = if (listening) Cyan else Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = vm::toggleVoice) { Text(if (voiceOn) "🔊" else "🔇") }
            IconButton(onClick = vm::clearHistory) { Icon(Icons.Default.Delete, "Clear history", tint = Color.Gray) }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.Gray) }
        }
        if (!imeOpen) {
            Box(Modifier.fillMaxWidth().clickable { vm.stopSpeaking() }, contentAlignment = Alignment.Center) { NovaAvatar(avatar, image) }
        }
        if (listening && partial.isNotBlank()) {
            Text(partial, color = Cyan, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        micError?.let { Text(it, color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp)) }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs, key = { it.id }) { m ->
                val mine = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (mine) Purple.copy(alpha = 0.85f) else Color(0xFF12262E),
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) { Text(m.text, Modifier.padding(12.dp), color = Color.White) }
                }
            }
        }
        pending?.let { a ->
            Surface(color = Color(0xFF12262E), shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(Commands.describe(a), color = Color.White)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { vm.confirmPending(true) }) { Text("Haan") }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { vm.confirmPending(false) }) { Text("Nahi", color = Cyan) }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, bottom = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text("Message Nova…") }, maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Cyan, unfocusedBorderColor = Teal)
            )
            IconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank()) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Cyan)
            }
            MicButton(listening, onMic)
        }
    }
}
