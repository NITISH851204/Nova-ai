package com.nova.ai.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

/** Stores the user-chosen character image privately inside the app. */
object AvatarStore {
    private fun file(c: Context) = File(c.filesDir, "avatar.png")

    fun load(c: Context): ImageBitmap? =
        file(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }

    fun save(c: Context, uri: Uri): ImageBitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / s > 1200) s *= 2
        val bmp = c.contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }!!
        file(c).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.asImageBitmap()
    }.getOrNull()

    fun clear(c: Context) { file(c).delete() }
}
