package com.nova.ai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" | "assistant"
    val text: String,
    val ts: Long = System.currentTimeMillis()
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY ts ASC") fun all(): Flow<List<MessageEntity>>
    @Insert suspend fun insert(m: MessageEntity)
    @Query("DELETE FROM messages") suspend fun clear()
}

@Database(entities = [MessageEntity::class], version = 1, exportSchema = false)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun dao(): MessageDao
    companion object {
        @Volatile private var inst: NovaDatabase? = null
        fun get(c: Context): NovaDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, NovaDatabase::class.java, "nova.db")
                .build().also { inst = it }
        }
    }
}
