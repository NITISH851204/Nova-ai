# Nova AI — Stage 1 (app skeleton + UI)
Build: open this folder in Android Studio (Koala+ / JDK 17), let Gradle sync (it generates the wrapper),
then Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk

Works: Compose UI, anime avatar, chat, Room history, mic (Android SpeechRecognizer, hi-IN).
Placeholder: AI replies (no provider connected). Not yet built: voice, AI providers, phone actions, memory, settings.
Not compiled/tested by the author: this environment has no Android SDK.
