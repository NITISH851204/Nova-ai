# Nova AI — Stage 1 (app skeleton + UI)
Build: open this folder in Android Studio (Koala+ / JDK 17), let Gradle sync (it generates the wrapper),
then Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk

Works: UI, avatar (vector or own image), chat, history, mic, AI providers (own key), voice replies (TTS), phone actions (open apps, YouTube search, Play Store search with confirm, settings, volume, media keys) + activity log.
Placeholder: AI replies (no provider connected). Not yet built: voice, AI providers, phone actions, memory, settings.
Not compiled/tested by the author: this environment has no Android SDK.
