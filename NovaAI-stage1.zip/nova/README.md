# Nova AI — Stage 1 (app skeleton + UI)
Build: open this folder in Android Studio (Koala+ / JDK 17), let Gradle sync (it generates the wrapper),
then Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk

Works: UI, avatar, chat, mic, AI providers (own key), TTS voice (with diagnostics), phone actions, YouTube control via limited AccessibilityService, activity log.
Placeholder: AI replies (no provider connected). Not yet built: voice, AI providers, phone actions, memory, settings.
Not compiled/tested by the author: this environment has no Android SDK.
